import javax.swing.*;
import java.awt.*;
 
public class SimpleGame extends JFrame implements Runnable {
    private Thread thread;
    private boolean running = false;
    private int x = 50;
    private int y = 50;
 
    public SimpleGame() {
        // 初始化窗口设置
        setSize(300, 300);
        setTitle("2D My World");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
 
        // 创建并启动游戏线程
        running = true;
        thread = new Thread(this);
        thread.start();
    }
 
    @Override
    public void run() {
        while (running) {
            repaint(); // 请求重绘窗口
            try {
                Thread.sleep(1000 / 60); // 每秒60次重绘
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
 
    @Override
    public void paint(Graphics g) {
        // 清除窗口
        super.paint(g);
 
        // 绘制背景
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, getWidth(), getHeight());
 
        // 绘制红色正方形
        g.setColor(Color.RED);
        g.fillRect(x, y, 50, 50);
    }
 
    public static void main(String[] args) {
        new SimpleGame();
    }
}