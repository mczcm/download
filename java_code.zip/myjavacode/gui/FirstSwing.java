import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FirstSwing {

	private static void createAndShowGUI() {
		// Create and set up the window.
		JFrame f1 = new JFrame("我的第一个图形化界面");
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// your code
		JPanel panel1 = new JPanel(new GridLayout(2, 2));
		JPanel panel2 = new JPanel(new FlowLayout());
		JLabel jlabel1 = new JLabel("用户名");
		JLabel jlabel2 = new JLabel("密码");
		JTextField jtf1 = new JTextField(15);
		JTextField jtf2 = new JTextField(15);
		JButton jbutton1 = new JButton("登录");
		JButton jbutton2 = new JButton("注册（未开放）");
		panel1.add(jlabel1);
		panel1.add(jtf1);
		panel1.add(jlabel2);
		panel1.add(jtf2);
		panel2.add(jbutton1);
		panel2.add(jbutton2);
		f1.add(panel2, BorderLayout.SOUTH);
		f1.add(panel1, BorderLayout.CENTER);

		// Display the window.
		f1.pack();
		f1.setVisible(true);

		jbutton1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String user = jtf1.getText();
				String password = jtf2.getText();
				if (user.equals("root") && password.equals("root")) {
					JOptionPane.showMessageDialog(null, "欢迎管理员进入系统");
				} else {
					JOptionPane.showMessageDialog(null, "输入错误或你不是管理员");
				}
			}
		});
	}

	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}
}
