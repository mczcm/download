import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
 
public class ShoppingCartSystem {
 public static void delay(int delayTime) {
        try {
            Thread.sleep(delayTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Product> cart = new ArrayList<>();
 
        System.out.println("欢迎来到购物系统！");
 
        while (true) {
            System.out.println("请输入商品编号添加到购物车，或者输入 'q' 退出:");
            String productId = scanner.nextLine();
 
            if ("q".equalsIgnoreCase(productId)) {
		delay(1000);
                break;
            }
 
            Product product = getProductById(productId);
            if (product != null) {
                cart.add(product);
                System.out.println("商品添加成功！");
            } else {
                System.out.println("未找到该商品，请确认商品编号是否正确。");
            }
        }
 
        System.out.println("您的购物车商品列表：");
        for (Product product : cart) {
            System.out.println(product);
        }
 
        double totalPrice = cart.stream().mapToDouble(Product::getPrice).sum();
        System.out.println("总价：" + totalPrice);
 
        scanner.close();
    }
 
    private static Product getProductById(String productId) {
        // 这里应该是查询数据库或者其他数据源获取商品信息
        // 为了示例，这里使用静态数据
        switch (productId) {
            case "1":
                return new Product("1", "笔记本电脑", 9999.99);
            case "2":
                return new Product("2", "手机", 3999.99);
            default:
                return null;
        }
    }
 
    static class Product {
        private String id;
        private String name;
        private double price;
 
        public Product(String id, String name, double price) {
            this.id = id;
            this.name = name;
            this.price = price;
        }
 
        public String getId() {
            return id;
        }
 
        public String getName() {
            return name;
        }
 
        public double getPrice() {
            return price;
        }
 
        @Override
        public String toString() {
            return "商品ID：" + id + ", 商品名称：" + name + ", 单价：" + price;
        }
    }
}