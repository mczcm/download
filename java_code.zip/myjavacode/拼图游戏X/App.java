package op1;

public class App {

	public static void main(String[] args) {
	//	new b(); //注册
		new a();  //登录
	//	new c();   //游戏
	}
}