package op1;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;

public class b {
	JFrame dk = new JFrame("登录");
	// 添加按钮
	JButton login = new JButton("登录");
	JButton exit = new JButton("退出");
	// 添加标签
	JLabel name1 = new JLabel("用户名");
	JLabel pwd1 = new JLabel("密码");
	// 添加文本输入框
	JTextField name = new JTextField(13);
	JTextField password = new JTextField(13);

	public LoginFrame() {
		initLoginJFrame();// 初始化界面
	}

	private void initLoginJFrame() {
		dk.setSize(210, 200);
		dk.setAlwaysOnTop(true);
		// dk.setLocationRelativeTo(null);
		dk.setDefaultCloseOperation(2);
		dk.setLayout(new FlowLayout());
		dk.add(name1);
		dk.add(name);
		dk.add(pwd1);
		dk.add(password);
		dk.add(login);
		dk.add(exit);
		login.addActionListener(this);
		exit.addActionListener(this);
		dk.setVisible(true);

	}

	private void initView() {

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == login) {
			if (name.getText().equals("") || password.getText().equals("")) {  当用户名或密码文本框内的内容为空时
				JOptionPane.showMessageDialog(this, "用名或密码不能为空");// 出现对话框提醒
				name.setText("");// 清空文本框
				password.setText("");// 清空文本框
			} else {
				try {
					BufferedWriter w = new BufferedWriter(new FileWriter("D:\\用户信息2.0.txt", true));// true追加录入，录入用户信息
					String sum = name.getText() + " " + password.getText();// 用户名与密码之间用空格连接
					BufferedReader r = new BufferedReader(new FileReader("D:\\用户信息2.0.txt"));// 读出用户信息
					String text;
					Boolean c = false;
					while ((text = r.readLine()) != null) {
						if (sum.equals(text)) { // 循环排查，看录入的信息是否与读取的信息相同，如果相同
							c = true;
						} // 则c为true,登陆成功,不同,c为false,则登录失败
					}
					if (c == true) {
						JOptionPane.showMessageDialog(this, "登录中！！！");
						dk.setVisible(false);// 关闭当前窗口
						new GameFrame();
					} else {
						JOptionPane.showMessageDialog(this, "用名或密码错误或没有注册，请重新输入或进入注册！！！");
						new RegistFrame();
						name.setText("");// 清空文本框
						password.setText("");// 清空文本框
					}

				} catch (IOException ee) {
				}
			}

		}
		if (e.getSource() == exit) {
			dk.setVisible(false);// 关闭当前窗口
		}

	}
}